#!/usr/bin/python3
# 0-square.py by Ehoneah Obed
"""Defines a square """


class Square:
    """Does nothing"""
    pass
