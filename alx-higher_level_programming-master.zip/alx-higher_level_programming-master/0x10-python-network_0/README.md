0x10. Python - Network #0
