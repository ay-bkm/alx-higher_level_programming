0x0D. SQL - Introduction
