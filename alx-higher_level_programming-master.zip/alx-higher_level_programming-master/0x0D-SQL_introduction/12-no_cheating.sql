-- updates teh score of Bob to 10 int the 
-- second table
-- using only the name field
UPDATE second_table SET score = 10 WHERE name = 'Bob';
