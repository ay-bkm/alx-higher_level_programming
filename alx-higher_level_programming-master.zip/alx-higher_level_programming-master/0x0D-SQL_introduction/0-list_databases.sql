-- list all databases of the MySQL server
SHOW DATABASES;
