-- computes score average of all records in the second_table
-- second table
SELECT AVG(score) AS average FROM second_table;
