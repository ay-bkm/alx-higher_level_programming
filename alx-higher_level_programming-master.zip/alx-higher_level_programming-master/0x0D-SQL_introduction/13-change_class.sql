-- removes all records where score is <= 5 from
-- second table
DELETE FROM second_table WHERE score <= 5;
