#!/usr/bin/python3

def add(a, b):
    """Return the sum of a and b."""
    return (a + b)
