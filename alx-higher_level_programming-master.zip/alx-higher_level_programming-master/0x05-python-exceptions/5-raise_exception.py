#!/usr/bin/python3
def raise_exception():
    """Raise a TypeError exception."""
    raise TypeError
