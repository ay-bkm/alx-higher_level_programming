0x0E. SQL - More queries
