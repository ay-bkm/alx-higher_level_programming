0x04. Python - More Data Structures: Set, Dictionary
