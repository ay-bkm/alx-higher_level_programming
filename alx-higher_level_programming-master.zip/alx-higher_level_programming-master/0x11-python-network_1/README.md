0x11. Python - Network #1
