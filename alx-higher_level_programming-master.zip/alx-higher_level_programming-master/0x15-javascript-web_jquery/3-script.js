$(document).ready(function () {
	$("DIV#red_header").click(function () {
		$("header").addClass("red");
	});
});
