document.readyState(function () {
  $('header').css('color', '#FF0000');
});
