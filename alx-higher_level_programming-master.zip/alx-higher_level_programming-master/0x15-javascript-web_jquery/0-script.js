const header = document.querySelector('header');

header.style.color = '#FF0000';
