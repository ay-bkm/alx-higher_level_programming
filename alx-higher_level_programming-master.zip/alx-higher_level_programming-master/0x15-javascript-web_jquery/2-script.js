document.readyState(function () {
  $('DIV#red_header').click(function () {
    $('header'.css('color', '#FF0000'));
  });
});
