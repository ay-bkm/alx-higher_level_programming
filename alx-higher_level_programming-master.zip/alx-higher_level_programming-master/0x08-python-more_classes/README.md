0x08. Python - More Classes and Objects
