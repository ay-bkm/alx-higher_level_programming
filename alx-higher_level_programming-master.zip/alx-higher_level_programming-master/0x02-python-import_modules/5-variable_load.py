#!/usr/bin/python3
from variable_load_5 import a

if __name__ != "__main__":
    exit()

print("{:d}".format(a))
