#!/usr/bin/node
// Script that prints "JavaScript is amazing".

const myVar =  “JavaScript is amazing”
console.log(myVar);
