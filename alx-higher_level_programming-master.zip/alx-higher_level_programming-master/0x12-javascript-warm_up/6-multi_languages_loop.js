#!/usr/bin/node

// script to print strings using a loop

let i;
const myString = ['C is fun', 'Python is cool', 'JavaScript is amazing'];

for (i = 0; i < 3; i++) {
  console.log(myString[i]);
}
