0x0F. Python - Object-relational mapping
