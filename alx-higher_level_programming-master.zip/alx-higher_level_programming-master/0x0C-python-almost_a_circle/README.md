0x0C. Python - Almost a circle
